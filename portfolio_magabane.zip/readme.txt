Magabane Liny — Portfolio Website

This package includes:
- index.html → Main portfolio page
- calculator.html → Tip calculator app
- restaurant.html → Restaurant demo site
- portfolio-demo.html → Demo portfolio template
- avatar.png → Small circle photo (header, 100px)
- aboutme.jpg → Larger photo (About Me section, 300px wide)
- favicon.ico → Small icon for browser tab
- cv.pdf → Placeholder CV (replace with your own)

✨ How to Deploy
1. Upload the folder to Netlify, Vercel, or GitHub Pages.
2. Your site will be live instantly.

📝 How to Update
- Change CV → Replace cv.pdf with your actual CV (keep the same filename).
- Change photos → Replace avatar.png and aboutme.jpg.
- Edit text → Open index.html in any text editor (like VS Code) and update the content.
